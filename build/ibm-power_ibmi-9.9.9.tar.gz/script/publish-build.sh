#!/bin/sh

version=`grep "version:" galaxy.yml | cut -d ":" -f 2 | cut -d " " -f 2`
#version = 1.0.0
echo $version
file=ibm-power_ibmi-${version}.tar.gz
new_file=ibm-power_ibmi-${version}.tar.gz
#new_file = ibm-power_ibmi-${version}-$TRAVIS_BUILD_NUMBER.tar.gz

dir=projects/a/ansible-for-i/${version}

IP=bejgsa.ibm.com

lftp -u ${GSA_USER},${GSA_PASSWORD} sftp://${IP} << EOF
cd  ${dir}
put ${new_file}
by
EOF