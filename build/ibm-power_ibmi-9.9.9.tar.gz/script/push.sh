#!/bin/sh
setup_git() {
  git config --global user.email "${GH_EMAIL}"
  git config --global user.name "Travis CI"
  git clone https://${GH_TOKEN}@github.com/IBM/ansible-for-i.git .temp
  cd .temp
}

commit_files() {
  git checkout git-sync
  rm -rf plugins/action/*
  rm -rf plugins/module_utils/*
  rm -rf plugins/modules/*
  rm -rf tests/integration/targets/ibmi*
  rm -rf roles/*
  rm -rf playbooks/*
  rm -rf docs/*
  ls -l plugins 
  if [ ! -d plugins/modules  ];then
  mkdir -p plugins/modules
  fi
  if [ ! -d plugins/action  ];then
  mkdir -p plugins/action
  fi
  if [ ! -d plugins/module_utils/ibmi  ];then
  mkdir -p plugins/module_utils/ibmi
  fi
  if [ ! -d roles  ];then
  mkdir -p roles
  fi
  if [ ! -d tests  ];then
  mkdir -p tests/integration/targets/
  fi
  if [ ! -d usecases/fix_management  ];then
  mkdir -p usecases/fix_management
  fi
  if [ ! -d usecases/security_management  ];then
  mkdir -p usecases/security_management
  fi
  if [ ! -d playbooks  ];then
  mkdir -p playbooks
  fi
  if [ ! -d docs/source  ];then
  mkdir -p docs/source
  fi
  if [ ! -d docs/templates  ];then
  mkdir -p docs/templates
  fi
  cp -r ../plugins/modules/* plugins/modules/
  cp -r ../plugins/action/* plugins/action/
  cp -r ../plugins/module_utils/ibmi/* plugins/module_utils/ibmi/
  cp -r ../tests/integration/targets/* tests/integration/targets/
  cp -r ../usecases/fix_management/* usecases/fix_management/
  cp -r ../usecases/security_management/* usecases/security_management/
  cp -r ../playbooks/* playbooks/
  cp -r ../roles/* roles/
  cp -r ../docs/source/* docs/source/
  cp -r ../docs/templates/* docs/templates/
  cp -r ../docs/Makefile docs/ 
  cp ../galaxy.yml .
  cp ../README.md .
  cp ../COPYING .
  rm -rf tests/integration/targets/ibmi_fix/files/*
  rm -rf tests/integration/targets/ibmi_display_fix/files/*
  rm -rf tests/integration/targets/ibmi_fix_imgclg/files/*
  rm -rf tests/integration/targets/ibmi_save_install_product/files/*
  rm -rf plugins/modules/ibmi_powervc*
  rm -rf plugins/module_utils/ibmi/__init__.py 
  git add .
  git commit --message "Travis build: $TRAVIS_BUILD_NUMBER"
}

upload_files() {
  git push --quiet --set-upstream origin git-sync
  cd ..
}

setup_git
commit_files
upload_files